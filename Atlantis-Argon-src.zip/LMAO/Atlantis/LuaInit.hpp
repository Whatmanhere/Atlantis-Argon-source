#include <iostream>
#include <Windows.h>
#include <string>

#include "oxorany/oxorany_include.h"
#include "XorStr.hpp"


auto skibidi = R"--(

    local function register(i, v)
        getgenv()[i] = v
        return v
    end
    

    
    do
        local CoreGui = game:GetService('CoreGui')
        local HttpService = game:GetService('HttpService')
    
        local comm_channels = CoreGui:FindFirstChild('comm_channels') or Instance.new('Folder', CoreGui)
        if comm_channels.Name ~= 'comm_channels' then
            comm_channels.Name = 'comm_channels'
        end
        register('create_comm_channel', newcclosure(function()
            local id = HttpService:GenerateGUID()
            local event = Instance.new('BindableEvent', comm_channels)
            event.Name = id
            return id, event
        end))
    
        register('get_comm_channel', newcclosure(function(id)
            assert(type(id) == 'string', 'string expected as argument #1')
            return comm_channels:FindFirstChild(id)
        end))
    end

    

    getgenv().getloadedmodules = newcclosure(function()
        local list = {}
        for i, v in getgc(false) do
        if typeof(v) == "function" then
                    local env = getfenv(v)
        if typeof(env["script"]) == "Instance" and env["script"]:IsA("ModuleScript") and not table.find(list, env["script"]) then
        table.insert(list, env["script"])
        end
        end
        end
        return list
        end)
        

    
    setreadonly(getgenv().debug,false)
    getgenv().debug.traceback = getrenv().debug.traceback
    getgenv().debug.profilebegin = getrenv().debug.profilebegin
    getgenv().debug.profileend = getrenv().debug.profileend
    getgenv().debug.getmetatable = getgenv().getrawmetatable
    getgenv().debug.setmetatable = getgenv().setrawmetatable
    getgenv().debug.info = getrenv().debug.info
    getgenv().debug.loadmodule = getrenv().debug.loadmodule

    getgenv().syn_mouse1press = mouse1press
    getgenv().syn_mouse2click = mouse2click
    getgenv().syn_mousemoverel = movemouserel
    getgenv().syn_mouse2release = mouse2up
    getgenv().syn_mouse1release = mouse1up
    getgenv().syn_mouse2press = mouse2down
    getgenv().syn_mouse1click = mouse1click
    getgenv().syn_newcclosure = newcclosure
    getgenv().syn_clipboard_set = setclipboard
    getgenv().syn_clipboard_get = getclipboard
    getgenv().syn_islclosure = islclosure
    getgenv().syn_iscclosure = iscclosure
    getgenv().syn_getsenv = getsenv
    getgenv().syn_getscripts = getscripts
    getgenv().syn_getgenv = getgenv
    getgenv().syn_getinstances = getinstances
    getgenv().syn_getreg = getreg
    getgenv().syn_getrenv = getrenv
    getgenv().syn_getnilinstances = getnilinstances
    getgenv().syn_fireclickdetector = fireclickdetector
    getgenv().syn_getgc = getgc
    
	--loadstring(game:HttpGet("https://raw.githubusercontent.com/lxzpwastaken/atlantis/refs/heads/main/drawing.luau"))()

    getgenv().info = function(...)
       game:GetService('TestService'):Message(table.concat({...}, ' '))
    end
)--";

